#! /bin/sh

# Script downgrade_resolution.sh
source $bc03/.bc_bash
$bc03/downgrade_resolution
source ./bc03.rm
\rm bc03.rm
