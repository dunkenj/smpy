#! /bin/sh

# Script csp_galaxev.sh
source $bc03/.bc_cshrc
$bc03/csp_galaxev
source ./bc03.rm
# \rm bc03.rm fort.501 *mxx*.ised
