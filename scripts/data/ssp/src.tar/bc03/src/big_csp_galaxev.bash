#! /bin/sh

# Script csp_galaxev.sh
source $bc03/.bc_bash
$bc03/big_csp_galaxev
source ./bc03.rm
\rm bc03.rm
