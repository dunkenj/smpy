#! /bin/sh

# Script cm_evolution.sh
source $bc03/.bc_bash
$bc03/cm_evolution
