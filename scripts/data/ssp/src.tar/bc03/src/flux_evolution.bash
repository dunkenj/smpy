#! /bin/sh

# Script flux_evolution.sh
source $bc03/.bc_bash
$bc03/flux_evolution
